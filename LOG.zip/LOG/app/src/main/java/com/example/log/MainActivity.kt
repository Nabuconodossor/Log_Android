package com.example.log

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {


    private lateinit var usuarioEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usuarioEditText = findViewById(R.id.usuarioText)
        passwordEditText = findViewById(R.id.passText)
        loginButton = findViewById(R.id.btnIngresar)


        //variable asignada para encontrar el ID del boton y cerrar App
        val button = findViewById<Button>(R.id.btnSalir)

        //accion del boton seteado Ingresar(inicia sesion)
        loginButton.setOnClickListener {
            ingresar()
        }

        //boton salir seteado para cerrar app desde pantalla inicio
        button.setOnClickListener {
            finishAffinity()
        }
    }
    //funcion para validar sesion
    private fun ingresar() {

        fun pantallaExodia() {
            val intent = Intent(this, Lug::class.java)
            startActivity(intent)
        }

        val usuario = usuarioEditText.text.toString()
        val clave = passwordEditText.text.toString()

        // Verificar si los datos ingresados coinciden
        if (usuario == "alumno" && clave == "1234") {
            // Autenticación exitosa
            Toast.makeText(this, "Ingreso Correcto.", Toast.LENGTH_SHORT).show()
            pantallaExodia()
            finish()
        } else {
            // Autenticación mala
            Toast.makeText(this, "Usuario incorrecto.", Toast.LENGTH_SHORT).show()
        }


    }
}