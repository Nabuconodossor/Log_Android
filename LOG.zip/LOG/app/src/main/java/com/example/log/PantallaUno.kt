package com.example.log

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class PantallaUno : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pantalla_uno)

        val btn: Button = findViewById(R.id.buttonBack)
        btn.setOnClickListener{
            val intent: Intent = Intent(this, Lug:: class.java)
            startActivity(intent)
        }
    }
}