package com.example.log

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.RatingBar
import android.widget.Toast

class Rating : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rating)

        val ratingBar:RatingBar = findViewById(R.id.rankingID)
        val progresBar:ProgressBar = findViewById(R.id.progressID)

        //obtener la calificacion seleccionada
        val rating = ratingBar.rating
        progresBar.visibility = View.INVISIBLE

        //Barra de progreso 
        progresBar.progress = 50

        ratingBar.numStars=5

        ratingBar.setOnRatingBarChangeListener{_,rating,_ ->
            Toast.makeText(this, "Calificacion: $rating", Toast.LENGTH_LONG)
            progresBar.visibility = View.VISIBLE
        }




    }
}